public class Ex_No_38_Decompile {
    public void sayHello() {
        System.out.println("Hello from Ex_No_38_Decompile!");
    }

    public static void main(String[] args) {
        Ex_No_38_Decompile sp = new Ex_No_38_Decompile();
        sp.sayHello();
    }
}
