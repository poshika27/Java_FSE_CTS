public class Ex_No_06_DataTypeDemonstration {
    public static void main(String[] args) {
        int i = 42;
        float f = 3.14f;
        double d = 2.71828;
        char c = 'A';
        boolean b = true;
        System.out.println("int: " + i);
        System.out.println("float: " + f);
        System.out.println("double: " + d);
        System.out.println("char: " + c);
        System.out.println("boolean: " + b);
    }
}
