public class Ex_No_07_TypeCastingExample {
    public static void main(String[] args) {
        double d = 9.99;
        int i = (int) d;
        System.out.println("Double to int: " + i);
        int j = 10;
        double e = j;
        System.out.println("Int to double: " + e);
    }
}
