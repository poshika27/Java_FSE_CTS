public class  Ex_No_37_InspectBytecode{
    public void sayHello() {
        System.out.println("Hello, Bytecode!");
    }
}
