package com.greetings;

import com.utils.Utility;

public class Main {
    public static void main(String[] args) {
        String message = Utility.getGreeting("Abishek");
        System.out.println(message);
    }
}
