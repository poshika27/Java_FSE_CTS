package com.utils;

public class Utility {
    public static String getGreeting(String name) {
        return "Hello, " + name + "! Welcome to Java Modules.";
    }
}
